from django.apps import AppConfig


class HomeappConfig(AppConfig):
    name = 'homeapp'
