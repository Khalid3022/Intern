from django.apps import AppConfig


class ContactappConfig(AppConfig):
    name = 'contactapp'
