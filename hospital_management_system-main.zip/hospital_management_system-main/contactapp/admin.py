from django.contrib import admin

from contactapp.models import Appointment,Contact

admin.site.register(Appointment)

admin.site.register(Contact)
