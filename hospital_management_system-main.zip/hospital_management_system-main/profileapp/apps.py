from django.apps import AppConfig


class ProfileappConfig(AppConfig):
    name = 'profileapp'
